
class Student:

    def __init__(self):
        # You may have to put code here.
        pass

    def get_by_id(self, ID):
        # Connect to DB.
        # Form SQL
        # Run query
        # return result
        return "Cool" + str(ID) + "!!"