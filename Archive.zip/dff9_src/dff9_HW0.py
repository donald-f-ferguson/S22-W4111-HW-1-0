
_my_uni = 'dff9'


def t1():
    return _my_uni + " says Hello World"